

import React, { Component } from 'react';
import { Text, View, StyleSheet, TextInput } from 'react-native';


export default class Imagenes extends Component {
render () {
 return (
 <View style={{flex:1}}>
     <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text>8</Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
     </View>
     <View style={{flex: 1}}>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
       <View style={{flex:1, flexDirection: 'row'}}>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
         <TextInput style={{flex:1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center',height: 50, borderColor: 'black', borderWidth: 1}}><Text></Text></TextInput>
       </View>
     </View>
 </View>
 )
}};
